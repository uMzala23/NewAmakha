<?php
$new_password = "Yolanda1001"; // CHANGE THIS to your new password
echo password_hash($new_password, PASSWORD_DEFAULT);
?>
